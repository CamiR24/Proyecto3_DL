let a = new Fantasma();

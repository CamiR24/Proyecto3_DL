let x: integer = 0;
while (x < 10) {
  if (x == 5) {
    break;
  }
  x = x + 1;
  continue;
}

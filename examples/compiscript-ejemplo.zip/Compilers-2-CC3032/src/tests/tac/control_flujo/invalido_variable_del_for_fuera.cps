for (let i: integer = 0; i < 3; i = i + 1) {
    print(i);
}
print(i);

print(a + b * c);
